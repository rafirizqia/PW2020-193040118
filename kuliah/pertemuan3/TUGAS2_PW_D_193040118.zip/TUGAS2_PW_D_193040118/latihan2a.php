 <?php

  $i = 1;
  while ($i <= 3) {
  	
  	for ($j=1; $j <= 3; $j++) { 
  		echo "Pengulangan ($i,$j)";

  		echo "<br>";
  	}
  	$i++;
  }
 ?>