<?php
	//perkalian
	$x = 15;
	echo "aku adalah angka $x <br>";

	$hasilkali = $x *= 5;
	echo "jika aku dikali 5 maka, aku sekarang bernilai $hasilkali <br>";

	//pembagian
	$hasilbagi = $x /= 3;
	echo "jika aku dibagi 3 maka, aku sekarang bernilai $hasilbagi <br>";

	//pengurangan
	$hasilkurang = $x -= 30;
	echo "jika aku di kurangi 30 maka, aku sekarang bernilai $hasilkurang <br>";

	//pertambahan
	$hasiltambah = $x += 10;
	echo "jika aku ditambah 10 maka, aku sekarang bernilai $hasiltambah";

?>